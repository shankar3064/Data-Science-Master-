export const TRANSLATIONS_EN = {
  Home: "Home",
  Exercises: "Awesome Exercises You Should Know",
  HomePageSlogan: "Sweat, Smile And Repeat",
  Homepage: "Check out the most effective exercises personalized to you",

  //404 error
  NotFound: "Page Not Found!!",
};
