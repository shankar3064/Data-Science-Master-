export const TRANSLATIONS_SP = {
  Home: "Inicio",
  Exercises: "Ejercicios impresionantes que debes saber",
  HomePageSlogan: "sudar, sonreir y repetir",
  Homepage: "Checa los ejercicios más efectivos personalizados para ti",

  //404 error
  NotFound: "Página no encontrada!!",
};
