import React from 'react'

const SimilarExercises = () => {
  return (
    <div>SimilarExercises</div>
  )
}

export default SimilarExercises